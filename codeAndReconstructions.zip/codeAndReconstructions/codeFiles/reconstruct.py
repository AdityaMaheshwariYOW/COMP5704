import scipy.io
import numpy as np
import tensorflow as tf
import time
import scipy.sparse
norms = [66.71730, 33.34396, 16.92447, 372.3057, 186.1538]

filename = "rec328-200k.py" 
it = 300000
mult = 4
norm = 2
matname = '/home/student/Documents/datasets/Walnut/Data328.mat'

print(filename)
print(it)
print(mult)
print("starting!")
t1 = time.time()

mat = scipy.io.loadmat(matname)
norm = 0
c1 = 82 * mult
c2 = 9840 * mult

Af = mat["A"]/norms[norm]  #norm
m = mat["m"].reshape((c2,1), order='F')
x0 = np.zeros((c1*c1, 1))

ind = np.nonzero(Af)
indl = list(map(list, zip(ind[0], ind[1])))
vals = Af[ind].tolist()[0]

#indlT = list(map(list, zip(ind[1], ind[0])))
print('\nprecompute took: %.4f sec\n\n' % (time.time() - t1))
t1 = time.time()

with tf.device('/GPU:0'):
    Atf = tf.sparse.SparseTensor(indices = indl, values = vals, dense_shape = [c2, c1*c1])
    #AT = tf.sparse.SparseTensor(indices = indlT, values = vals, dense_shape = [c1*c1, c2])
    y = tf.convert_to_tensor(m, dtype='float32')
    x = tf.Variable(tf.zeros((c1*c1, 1)))

    yMax = tf.norm(y - tf.sparse.sparse_dense_matmul(Atf, x), 2)
    optimizer = tf.train.GradientDescentOptimizer(0.05)
    train = optimizer.minimize(yMax)
    #update = x.assign(x + tf.scalar_mul(0.05, tf.sparse.sparse_dense_matmul(AT, yMax)))
    init = tf.global_variables_initializer()

print('\nTensorflow load took: %f sec\n\n' % (time.time() - t1))
t1 = time.time()

sess = tf.Session()

sess.run(init)
sess.run(train)

print('\nTensorflow initialized: %f sec\n\n' % (time.time() - t1))
t2 = time.time()

for i in range(it):
    sess.run(train)

t3 = time.time()
elapsed = t3 - t2

print('\ntraining took: %f sec\n\n' % elapsed)
print('\nL2-norm: %f\n\n' % sess.run(yMax))
print('\nL1-norm: %f\n\n' % sess.run(tf.norm(y - tf.sparse.sparse_dense_matmul(Atf, x), 1 )))

np.savetxt(filename, sess.run(x))


