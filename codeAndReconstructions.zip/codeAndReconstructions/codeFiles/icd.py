import os
import sys
import scipy.io
import numpy as np
import time
import scipy.sparse
import scipy.sparse.linalg
from random import shuffle
norms = [66.71730, 33.34396, 16.92447, 372.3057, 186.1538]

t1 = time.time()
mat = scipy.io.loadmat('./LotusXRAY/LotusData128.mat')
#mat = scipy.io.loadmat('./Walnut/Data328.mat')
norm = 3
mult = 1
c1 = 128*mult
c2 = 51480

Af = mat["A"]/norms[norm] #norm
m = mat["m"].reshape((c2,1), order='F')
x0 = np.zeros((c1*c1, 1))

ind = np.nonzero(Af)
indl = list(map(list, zip(ind[0], ind[1])))
vals = Af[ind].tolist()[0]

#indlT = list(map(list, zip(ind[1], ind[0])))
print(time.time() - t1)

def icdUpdate(A, f, g, cols = c1, it=1):
    time1 = time.time()
    cols = cols*cols
    err = np.subtract(g, np.matmul(A, f))
    print(np.sum(np.abs(err)))
    for j in range(it):
        order = np.random.choice(cols, cols, replace=False)
        for i in order:
            t1 = np.sum(np.multiply(-1.0*err, A[:,i]))
            t2 = np.sum(np.multiply(A[:,i], A[:,i]))
            alpha = max(np.divide(-1*t1,t2), -f[i])
            f[i] += alpha
            err -= A[:,i]*alpha
        print(np.sum(np.abs(err)))
        print(time.time() - time1)
    return(f)

x0 = np.zeros((c1*c1, 1))
b = time.time()
newF = icdUpdate(Af.todense(), np.asmatrix(x0), np.asmatrix(m), it=35)
print(time.time() - b)

np.savetxt("./icdRec128.csv", newF)


